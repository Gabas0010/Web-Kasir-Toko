<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class ModelFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $controller = $request->controllerName();
        $modelClass = "App\\Models\\" . $controller . 'Model';

        if (class_exists($modelClass)) {
            $controllerInstance = service($controller);
            $controllerInstance->{$controller . 'Model'} = new $modelClass();
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada tindakan setelahnya
    }
}
